
import type { EmployeeInput, PayslipData, PayrollConfig } from '../types';

function calculateTaxFreeAllowance(grossSalary: number, config: PayrollConfig): number {
  if (grossSalary <= config.taxFreeAllowanceLowerBound) {
    return config.taxFreeAllowanceMax;
  }
  if (grossSalary >= config.taxFreeAllowanceUpperBound) {
    return 0;
  }
  // Linear decrease formula: 500 - (500/900 * (Gross - 1200))
  const decreaseFactor = config.taxFreeAllowanceMax / (config.taxFreeAllowanceUpperBound - config.taxFreeAllowanceLowerBound);
  const allowance = config.taxFreeAllowanceMax - decreaseFactor * (grossSalary - config.taxFreeAllowanceLowerBound);
  return Math.max(0, allowance);
}

export function calculatePayroll(input: EmployeeInput, config: PayrollConfig): PayslipData {
  const { grossSalary, useTaxFreeAllowance, isIIpillarActive, isExemptFromMinSocialTax } = input;

  const taxFreeAllowance = useTaxFreeAllowance ? calculateTaxFreeAllowance(grossSalary, config) : 0;
  
  const employeeUnemploymentInsurance = grossSalary * config.employeeUnemploymentRate;
  
  const pillar2Pension = isIIpillarActive ? grossSalary * config.pillar2Rate : 0;

  const taxableIncome = Math.max(0, grossSalary - taxFreeAllowance - employeeUnemploymentInsurance - pillar2Pension);
  
  const incomeTax = taxableIncome * config.incomeTaxRate;

  const employeeContributions = incomeTax + employeeUnemploymentInsurance + pillar2Pension;

  const netSalary = grossSalary - employeeUnemploymentInsurance - pillar2Pension - incomeTax;

  const minSocialTaxContribution = config.minSocialTaxBase * config.socialTaxRate;
  let employerSocialTax = grossSalary * config.socialTaxRate;
  if (!isExemptFromMinSocialTax) {
    employerSocialTax = Math.max(employerSocialTax, minSocialTaxContribution);
  }

  const employerUnemploymentInsurance = grossSalary * config.employerUnemploymentRate;
  
  const employerContributions = employerSocialTax + employerUnemploymentInsurance;
  
  const totalEmployerCost = grossSalary + employerContributions;

  return {
    grossSalary,
    taxFreeAllowance,
    employeeUnemploymentInsurance,
    pillar2Pension,
    taxableIncome,
    incomeTax,
    netSalary,
    employerSocialTax,
    employerUnemploymentInsurance,
    totalEmployerCost,
    employeeContributions,
    employerContributions,
  };
}
