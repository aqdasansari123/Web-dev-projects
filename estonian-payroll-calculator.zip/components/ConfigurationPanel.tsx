import React from 'react';
import type { PayrollConfig } from '../types';
import { CogIcon } from './icons';

interface ConfigurationPanelProps {
  config: PayrollConfig;
  onConfigChange: React.Dispatch<React.SetStateAction<PayrollConfig>>;
}

const ConfigurationPanel: React.FC<ConfigurationPanelProps> = ({ config, onConfigChange }) => {
  
  const handleNumericChange = <K extends keyof PayrollConfig,>(key: K, value: string, isPercentage: boolean = false) => {
    let numericValue = parseFloat(value);
    if (isNaN(numericValue)) numericValue = 0;
    if (isPercentage) {
        numericValue /= 100;
    }
    onConfigChange(prevConfig => ({ ...prevConfig, [key]: numericValue }));
  };

  const ConfigInput = ({ label, value, id, isPercentage = false }: { label: string; value: number; id: keyof PayrollConfig, isPercentage?: boolean }) => (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-gray-700">{label}</label>
      <div className="mt-1 relative rounded-md shadow-sm">
        <input
          type="number"
          id={id}
          name={id}
          value={isPercentage ? (value * 100).toFixed(2) : value.toFixed(2)}
          onChange={(e) => handleNumericChange(id, e.target.value, isPercentage)}
          className="block w-full pl-3 pr-10 py-2 bg-gray-700 text-white border-gray-600 rounded-md focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          step={isPercentage ? "0.01" : "1"}
        />
        <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
          <span className="text-gray-500 sm:text-sm">{isPercentage ? '%' : '€'}</span>
        </div>
      </div>
    </div>
  );

  return (
    <details className="bg-white p-6 rounded-2xl shadow-lg border border-gray-200 open:ring-2 open:ring-indigo-500 transition-shadow" open>
      <summary className="flex items-center gap-3 cursor-pointer text-xl font-bold text-gray-800 list-none">
        <CogIcon className="w-6 h-6 text-gray-500" />
        Configuration
      </summary>
      <div className="mt-6 space-y-4 border-t border-gray-200 pt-4">
        <ConfigInput label="Income Tax Rate" value={config.incomeTaxRate} id="incomeTaxRate" isPercentage />
        <ConfigInput label="Social Tax Rate" value={config.socialTaxRate} id="socialTaxRate" isPercentage />
        <ConfigInput label="Minimum Social Tax Base" value={config.minSocialTaxBase} id="minSocialTaxBase" />
        <ConfigInput label="Employee Unemployment Rate" value={config.employeeUnemploymentRate} id="employeeUnemploymentRate" isPercentage />
        <ConfigInput label="Employer Unemployment Rate" value={config.employerUnemploymentRate} id="employerUnemploymentRate" isPercentage />
        <ConfigInput label="II Pillar Pension Rate" value={config.pillar2Rate} id="pillar2Rate" isPercentage />
        <ConfigInput label="Max. Tax-Free Allowance" value={config.taxFreeAllowanceMax} id="taxFreeAllowanceMax" />
        <ConfigInput label="Allowance Lower Bound (Gross)" value={config.taxFreeAllowanceLowerBound} id="taxFreeAllowanceLowerBound" />
        <ConfigInput label="Allowance Upper Bound (Gross)" value={config.taxFreeAllowanceUpperBound} id="taxFreeAllowanceUpperBound" />
      </div>
    </details>
  );
};

export default ConfigurationPanel;