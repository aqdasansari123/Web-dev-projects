import React from 'react';
import type { PayslipData } from '../types';
import { PAYSLIP_LABELS } from '../constants';
import { RefreshIcon } from './icons';

interface PayslipProps {
  data: PayslipData;
  onReset: () => void;
}

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('et-EE', { style: 'currency', currency: 'EUR' }).format(amount);
};

const Payslip: React.FC<PayslipProps> = ({ data, onReset }) => {

    const PayslipRow = ({ labelKey, value, isNegative = false, isBold = false, isSubtle = false }: { labelKey: keyof typeof PAYSLIP_LABELS; value: number; isNegative?: boolean; isBold?: boolean; isSubtle?: boolean }) => {
        const labels = PAYSLIP_LABELS[labelKey];
        const textColor = isNegative ? 'text-red-600' : isSubtle ? 'text-gray-600' : 'text-gray-900';
        const fontWeight = isBold ? 'font-bold' : 'font-medium';
        return (
            <tr className={isBold ? "bg-gray-100" : ""}>
                <td className={`py-3 px-4 sm:px-6 ${fontWeight} ${textColor}`}>{labels.et}</td>
                <td className={`py-3 px-4 sm:px-6 text-gray-500 hidden md:table-cell`}>{labels.de} / {labels.en}</td>
                <td className={`py-3 px-4 sm:px-6 text-right ${fontWeight} ${textColor}`}>{isNegative ? '-' : ''}{formatCurrency(value)}</td>
            </tr>
        );
    };

    const SummaryCard = ({ title, value, colorClass }: { title: string; value: number; colorClass: string }) => (
        <div className={`${colorClass} p-4 rounded-lg text-center text-white shadow-lg`}>
            <p className="text-sm font-medium opacity-90">{title}</p>
            <p className="text-2xl font-bold">{formatCurrency(value)}</p>
        </div>
    );

  return (
    <div className="space-y-6">
        <div className="flex justify-between items-start">
            <div>
                <h2 className="text-2xl font-bold text-gray-900">Payslip Result</h2>
                <p className="text-gray-600 mt-1">Based on a gross salary of {formatCurrency(data.grossSalary)}.</p>
            </div>
            <button onClick={onReset} className="flex items-center gap-2 bg-white text-gray-700 font-semibold py-2 px-4 rounded-lg border border-gray-300 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all">
                <RefreshIcon className="w-5 h-5" />
                New Calculation
            </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <SummaryCard title="Net Salary (Take Home)" value={data.netSalary} colorClass="bg-green-600" />
            <SummaryCard title="Total Employee Cost" value={data.totalEmployerCost} colorClass="bg-blue-600" />
            <SummaryCard title="Total Taxes & Contributions" value={data.employeeContributions + data.employerContributions} colorClass="bg-orange-600" />
        </div>

      <div className="overflow-x-auto bg-white rounded-lg border border-gray-200">
        <table className="w-full text-sm text-left">
          <thead className="bg-gray-50 border-b border-gray-200 text-xs text-gray-500 uppercase tracking-wider">
            <tr>
              <th scope="col" className="py-3 px-4 sm:px-6 font-semibold">Position (ET)</th>
              <th scope="col" className="py-3 px-4 sm:px-6 font-semibold hidden md:table-cell">Description (DE / EN)</th>
              <th scope="col" className="py-3 px-4 sm:px-6 font-semibold text-right">Amount (€)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            <PayslipRow labelKey="grossSalary" value={data.grossSalary} isBold />
            
            {data.employeeUnemploymentInsurance > 0 && <PayslipRow labelKey="employeeUnemploymentInsurance" value={data.employeeUnemploymentInsurance} isNegative />}
            {data.pillar2Pension > 0 && <PayslipRow labelKey="pillar2Pension" value={data.pillar2Pension} isNegative />}
            {data.incomeTax > 0 && <PayslipRow labelKey="incomeTax" value={data.incomeTax} isNegative />}
            
            <PayslipRow labelKey="netSalary" value={data.netSalary} isBold />

            <tr className="bg-gray-100"><td colSpan={3} className="py-2"></td></tr>

            <tr className="bg-gray-50"><td colSpan={3} className="pt-3 pb-1 px-4 sm:px-6 text-xs text-gray-500 uppercase tracking-wider font-semibold">Employer Contributions</td></tr>
            <PayslipRow labelKey="employerSocialTax" value={data.employerSocialTax} isSubtle />
            <PayslipRow labelKey="employerUnemploymentInsurance" value={data.employerUnemploymentInsurance} isSubtle />
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Payslip;