import React from 'react';
import type { EmployeeInput } from '../types';

interface InputFormProps {
  input: EmployeeInput;
  onInputChange: React.Dispatch<React.SetStateAction<EmployeeInput>>;
  onCalculate: () => void;
}

const InputForm: React.FC<InputFormProps> = ({ input, onInputChange, onCalculate }) => {
  const handleGrossSalaryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    onInputChange(prev => ({ ...prev, grossSalary: isNaN(value) ? 0 : value }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    onInputChange(prev => ({ ...prev, [name]: checked }));
  };

  const Switch = ({ id, label, checked, onChange }: { id: keyof EmployeeInput; label: string; checked: boolean; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void }) => (
    <label htmlFor={id as string} className="flex items-center justify-between cursor-pointer bg-gray-50 p-4 rounded-lg border border-gray-200 hover:bg-gray-100 transition-colors">
      <span className="font-medium text-gray-700">{label}</span>
      <div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in">
        <input
          type="checkbox"
          name={id as string}
          id={id as string}
          checked={checked}
          onChange={onChange}
          className="toggle-checkbox absolute block w-6 h-6 rounded-full bg-white border-4 appearance-none cursor-pointer"
        />
        <label htmlFor={id as string} className="toggle-label block overflow-hidden h-6 rounded-full bg-gray-300 cursor-pointer"></label>
      </div>
      <style>{`.toggle-checkbox:checked { right: 0; border-color: #4f46e5; } .toggle-checkbox:checked + .toggle-label { background-color: #4f46e5; }`}</style>
    </label>
  );

  return (
    <div className="space-y-8">
        <div>
            <h2 className="text-2xl font-bold text-gray-900">Calculate Payroll</h2>
            <p className="text-gray-600 mt-1">Enter the gross salary and select employee options.</p>
        </div>
        <div className="space-y-6">
            <div>
            <label htmlFor="grossSalary" className="block text-sm font-bold text-gray-700 mb-1">
                Gross Monthly Salary
            </label>
            <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <span className="text-gray-500 sm:text-sm">€</span>
                </div>
                <input
                    type="number"
                    name="grossSalary"
                    id="grossSalary"
                    className="block w-full rounded-md bg-gray-700 text-white border-gray-600 pl-7 pr-12 py-3 focus:border-indigo-500 focus:ring-indigo-500 text-lg placeholder-gray-400"
                    placeholder="0.00"
                    value={input.grossSalary}
                    onChange={handleGrossSalaryChange}
                />
            </div>
            </div>

            <div className="space-y-4">
            <Switch id="useTaxFreeAllowance" label="Apply Tax-Free Allowance" checked={input.useTaxFreeAllowance} onChange={handleCheckboxChange} />
            <Switch id="isIIpillarActive" label="Joined II Pillar Pension" checked={input.isIIpillarActive} onChange={handleCheckboxChange} />
            <Switch id="isExemptFromMinSocialTax" label="Exempt from Minimum Social Tax" checked={input.isExemptFromMinSocialTax} onChange={handleCheckboxChange} />
            </div>
        </div>

        <button
            onClick={onCalculate}
            className="w-full bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all duration-300 text-lg shadow-md hover:shadow-lg"
        >
            Calculate
        </button>
    </div>
  );
};

export default InputForm;