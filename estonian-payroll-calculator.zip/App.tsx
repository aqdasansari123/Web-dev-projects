
import React, { useState, useCallback } from 'react';
import type { EmployeeInput, PayslipData, PayrollConfig } from './types';
import { DEFAULT_CONFIG } from './constants';
import { calculatePayroll } from './services/payrollService';
import ConfigurationPanel from './components/ConfigurationPanel';
import InputForm from './components/InputForm';
import Payslip from './components/Payslip';

const App: React.FC = () => {
  const [config, setConfig] = useState<PayrollConfig>(DEFAULT_CONFIG);
  const [employeeInput, setEmployeeInput] = useState<EmployeeInput>({
    grossSalary: 2000,
    useTaxFreeAllowance: true,
    isIIpillarActive: false,
    isExemptFromMinSocialTax: false,
  });
  const [payslipData, setPayslipData] = useState<PayslipData | null>(null);

  const handleCalculate = useCallback(() => {
    const results = calculatePayroll(employeeInput, config);
    setPayslipData(results);
  }, [employeeInput, config]);

  const handleReset = () => {
    setPayslipData(null);
    setEmployeeInput({
        grossSalary: 2000,
        useTaxFreeAllowance: true,
        isIIpillarActive: false,
        isExemptFromMinSocialTax: false,
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-sans p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8 pb-4 border-b border-gray-200">
          <div>
            <h1 className="text-3xl sm:text-4xl font-bold text-gray-900">Estonian Payroll Calculator</h1>
            <p className="text-md text-gray-600 mt-1">A tool to model salary calculations based on Estonian tax laws.</p>
          </div>
        </header>

        <main className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1 space-y-8">
            <ConfigurationPanel config={config} onConfigChange={setConfig} />
          </div>

          <div className="lg:col-span-2">
             <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg border border-gray-200">
                {!payslipData ? (
                    <InputForm 
                        input={employeeInput} 
                        onInputChange={setEmployeeInput} 
                        onCalculate={handleCalculate} 
                    />
                ) : (
                    <Payslip data={payslipData} onReset={handleReset} />
                )}
             </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;