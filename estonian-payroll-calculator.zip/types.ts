
export interface PayrollConfig {
  incomeTaxRate: number;
  socialTaxRate: number;
  minSocialTaxBase: number;
  employeeUnemploymentRate: number;
  employerUnemploymentRate: number;
  pillar2Rate: number;
  taxFreeAllowanceMax: number;
  taxFreeAllowanceLowerBound: number;
  taxFreeAllowanceUpperBound: number;
}

export interface EmployeeInput {
  grossSalary: number;
  useTaxFreeAllowance: boolean;
  isIIpillarActive: boolean;
  isExemptFromMinSocialTax: boolean;
}

export interface PayslipData {
  grossSalary: number;
  taxFreeAllowance: number;
  employeeUnemploymentInsurance: number;
  pillar2Pension: number;
  taxableIncome: number;
  incomeTax: number;
  netSalary: number;
  employerSocialTax: number;
  employerUnemploymentInsurance: number;
  totalEmployerCost: number;
  employeeContributions: number;
  employerContributions: number;
}
