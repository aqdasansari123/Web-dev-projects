
import type { PayrollConfig } from './types';

export const DEFAULT_CONFIG: PayrollConfig = {
  incomeTaxRate: 0.20,
  socialTaxRate: 0.33,
  minSocialTaxBase: 725.00,
  employeeUnemploymentRate: 0.016,
  employerUnemploymentRate: 0.008,
  pillar2Rate: 0.02,
  taxFreeAllowanceMax: 500,
  taxFreeAllowanceLowerBound: 1200,
  taxFreeAllowanceUpperBound: 2100,
};

export const PAYSLIP_LABELS = {
  grossSalary: { et: 'Põhipalk', de: 'Grundgehalt', en: 'Base Salary' },
  incomeTax: { et: 'Tulumaks', de: 'Einkommensteuer', en: 'Income Tax' },
  employeeUnemploymentInsurance: { et: 'Töötaja töötuskindlustus', de: 'AN-Arbeitslosenvers.', en: 'Employee Unempl. Ins.' },
  pillar2Pension: { et: 'II sammas', de: 'II. Säule', en: 'Pension Pillar II' },
  netSalary: { et: 'Neto', de: 'Netto', en: 'Net Salary' },
  employerSocialTax: { et: 'Tööandja sotsiaalmaks', de: 'AG-Sozialsteuer', en: 'Employer Social Tax' },
  employerUnemploymentInsurance: { et: 'Tööandja töötuskindlustus', de: 'AG-Arbeitslosenvers.', en: 'Employer Unempl. Ins.' },
};
